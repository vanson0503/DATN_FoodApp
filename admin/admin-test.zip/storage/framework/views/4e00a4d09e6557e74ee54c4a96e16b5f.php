

<?php $__env->startSection('content'); ?>
    <form id="addCategoryForm" enctype="multipart/form-data">
        <label for="name">Category Name:</label><br>
        <input type="text" id="name" name="name" required><br><br>
        
        <label for="image">Category Image:</label><br>
        <input type="file" id="image" name="image" accept="image/*" required><br><br>
        
        <button type="submit">Add Category</button>
    </form>

    <script>
        document.getElementById('addCategoryForm').addEventListener('submit', function(event) {
            event.preventDefault();

            // Tạo đối tượng FormData để gửi dữ liệu form
            var formData = new FormData(this);

            // Gửi yêu cầu POST đến API
            fetch('http://localhost/food-api/public/api/category', {
                method: 'POST', 
            
                body: formData
            })
            .then(response => {
                if (!response.ok) {
                    alert(response);
                }
                return response.json();
            })
            .then(data => {
                alert(data.message);
                window.location.reload();
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Failed to add category');
            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('../layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin\resources\views/category/create.blade.php ENDPATH**/ ?>