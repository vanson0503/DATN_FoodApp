

<?php $__env->startSection('content'); ?>
    Hello world 
<?php $__env->stopSection(); ?>


<?php echo $__env->make('../layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin-test\resources\views/home.blade.php ENDPATH**/ ?>