

<?php $__env->startSection('content'); ?>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://chat-server-tq8x.onrender.com/socket.io/socket.io.js"></script>
    <script>
        
        const socket = io("https://chat-server-tq8x.onrender.com/");
            const room = 1;
            socket.emit("join", room);
            console.log(`Joined room ${room}`);



        socket.on("thread", function (data) {
            const parsedMessage = JSON.parse(data);
            displayMessage(parsedMessage);
            console.log(`Received message: ${JSON.stringify(data)}`);
        });

        socket.on("history", function (data) {
            document.getElementById('messageList').innerHTML = ""
            const messages = JSON.parse(JSON.stringify(data));
            messages.forEach(message => {
                displayMessage(message);
            });
            console.log(`Chat history: ${JSON.stringify(data)}`);
        });

    </script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin-test\resources\views/chat/chatdetail.blade.php ENDPATH**/ ?>