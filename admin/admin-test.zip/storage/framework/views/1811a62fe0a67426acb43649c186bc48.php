

<?php $__env->startSection('content'); ?>
<div class="container">
    <form id="updateCategoryForm" enctype="multipart/form-data">
        <input type="hidden" id="categoryId" name="id" value="<?php echo e($category->id); ?>" required><br><br>
        
        <div class="form-group">
            <label for="name">New Category Name:</label>
            <input type="text" class="form-control" id="name" name="name" value="<?php echo e($category->name); ?>" required>
        </div>
        
        <div class="form-group">
            <label for="image">New Category Image:</label>
            <input type="file" class="form-control-file" id="image" name="image" accept="image/*">
        </div>

        <img id="categoryImage" src="<?php echo e("http://localhost/food-api/storage/app/public/category_images/" . $category->image_url); ?>" alt="Category Image" class="img-fluid"><br><br>
        
        <button type="submit" class="btn btn-primary">Update Category</button>
    </form>

</div>

<script>
    var categoryId = "<?php echo e($category->id); ?>";

    document.getElementById('categoryId').value = categoryId;

    document.getElementById('updateCategoryForm').addEventListener('submit', function(event) {
        event.preventDefault();

        // Tạo đối tượng FormData để gửi dữ liệu form
        var formData = new FormData(this);

        // Gửi yêu cầu POST đến API
        fetch('http://localhost/food-api/public/api/category/' + categoryId, {
            method: 'POST', // Sử dụng phương thức POST
            headers: {
                'X-HTTP-Method-Override': 'PUT', // Ghi đè phương thức POST bằng PUT
            },
            body: formData
        })
        .then(response => {
            if (!response.ok) {
                alert(response);
            }
            return response.json();
        })
        .then(data => {
            alert(data.message);
            window.location.reload();
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Failed to update category');
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin\resources\views/category/edit.blade.php ENDPATH**/ ?>