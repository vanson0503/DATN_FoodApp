@extends('../layout')

@section('content')
    Hello world 
@endsection

